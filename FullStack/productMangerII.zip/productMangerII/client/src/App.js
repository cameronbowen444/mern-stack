import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Main from './views/Main';
import Detail from './Components/Detail';
import Update from './Components/Update';

function App() {
  return (
    <div className="App">
      <h1>Your Product</h1>
      <BrowserRouter>
        <Routes>
          <Route element={<Main/>} path="/" />
          <Route element={<Detail/>} path="/products/:id" />
          <Route element={<Update/>} path="/products/edit/:id" />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
