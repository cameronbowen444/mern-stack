import React, {useState, useEffect} from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';

const PetForm = (props) => {

    const [name, setName] = useState("");
    const [petType, setPetType] = useState("");
    const [description, setDescription] = useState("");
    const [skill1, setSkill1] = useState("");
    const [skill2, setSkill2] = useState("");
    const [skill3, setSkill3] = useState("");
    const [errors, setErrors] = useState({});
    const navigate = useNavigate();

    const onSubmitHandle = (e) => {
        e.preventDefault();
        axios.post('http://localhost:8000/api/pets', {
            name,
            petType,
            description,
            skill1,
            skill2,
            skill3
        })
            .then(res => {
                console.log(res);
                console.log(res.data);
                navigate("/");
            })
            .catch(err => {
                console.log(err.response.data.err.errors);
                setErrors(err.response.data.err.errors);
            })
    }
    return(
        <div>
            <div className='container'>
                <div className='row justify-content-between'>
                    <div className='col-4'>
                        <h5>Know a pet needing a home?</h5>
                    </div>
                    <div className='col-4 link'>
                        <Link className="btn btn-primary" to={'/'}>Home</Link>
                    </div>
                </div>
                <form onSubmit={onSubmitHandle} className="form">
                    <div className='row justify-content-between'>
                        <h2 className="form-title">Add Pet:</h2>
                        <div className='col-4'>
                            <div className='mb-3'>
                                <label className='form-label'>Pet Name:</label>
                                <input className='form-control' type="text" value={name} onChange={(e) => setName(e.target.value)}/>
                                {
                                    errors.name ? <p className="error">{errors.name.message}</p> : null
                                }
                            </div>
                            <div className='mb-3'>
                                <label className='form-label'>Pet Type:</label>
                                <input className='form-control' type="text" value={petType} onChange={(e) => setPetType(e.target.value)}/>
                                {
                                    errors.petType ? <p className="error">{errors.petType.message}</p> : null
                                }
                            </div>
                            <div className='mb-3'>
                                <label className='form-label'>Pet Description:</label>
                                <input className='form-control' type="text" value={description} onChange={(e) => setDescription(e.target.value)}/>
                                {
                                    errors.description ? <p className="error">{errors.description.message}</p> : null
                                }
                            </div>
                        </div>
                        <div className='col-4'>
                            <p>Optional Skills:</p>
                            <div className='mb-3'>
                                <label className='form-label'>Pet Skill 1 <span>(optional)</span>:</label>
                                <input className='form-control' type="text" value={skill1} onChange={(e) => setSkill1(e.target.value)}/>
                            </div>
                            <div className='mb-3'>
                                <label className='form-label'>Pet Skill 2 <span>(optional)</span>:</label>
                                <input className='form-control' type="text" value={skill2} onChange={(e) => setSkill2(e.target.value)}/>
                            </div>
                            <div className='mb-3'>
                                <label className='form-label'>Pet Skill 3 <span>(optional)</span>:</label>
                                <input className='form-control' type="text" value={skill3} onChange={(e) => setSkill3(e.target.value)}/>
                            </div>
                        </div>
                        <div className="button">
                            <input type="submit" className="btn btn-primary btn4" />
                        </div>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default PetForm;