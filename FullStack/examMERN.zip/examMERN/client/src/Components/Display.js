import React, {useState, useEffect} from 'react';
import axios from 'axios';
import {Link} from 'react-router-dom';

const Display = (props) => {

    const [pets, setPets] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:8000/api/pets')
        .then(res => {
            console.log(res.data);
            setPets(res.data);
        })
        .catch(err => {
            console.log(err);
        })
    }, [])

    const deleteThisPet = (delId) => {
        axios.delete('http://localhost:8000/api/pets/' + delId)
        .then(res => {
            const filterPets = pets.filter((pets) => {
                return pets._id !== delId;
            });
            setPets(filterPets);
        })
        .catch(err => {
            console.log(err);
        })
    }

    return(
        <div className='container'>
            <div className='row justify-content-between'>
                <div className='col-4'>
                    <h5>These pets are looking for a good home</h5>
                </div>
                <div className='col-4 link'>
                    <Link className="btn btn-primary" to={'/new'}>Add A Pet</Link>
                </div>
            </div>
            <table className='table table-dark table-bordered'>
                <thead>
                    <tr>
                        <th scope="col">Name</th>
                        <th scope="col">Type</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody className="table-group-divider">
                    {
                        pets.map((pet, index) => {
                            return(
                                <tr key={index} className="table-secondary">
                                    <td>{pet.name}</td>
                                    <td>{pet.petType}</td>
                                    <td><Link className="btn btn-primary btn1" to={'/show/' + pet._id}>Details</Link> <Link className="btn btn-primary btn2" to={'/edit/' + pet._id}>Edit</Link> <button className="btn btn-success btn3" onClick={() => deleteThisPet(pet._id)}>Adopt {pet.name}</button></td>
                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
        </div>
    );
};

export default Display;