import React, {useState, useEffect} from 'react';
import axios from 'axios';
import { useParams, Link } from 'react-router-dom';

const ShowPet = (props) => {

    const {filterPets} = props;

    const [pet, setPet] = useState({})
    const {id} = useParams();
    useEffect(() => {
        axios.get('http://localhost:8000/api/pets/' + id)
        .then(res => {
            console.log(res.data);
            setPet(res.data);
        })
        .catch(err => {
            console.log(err);
        })
    }, [])

    return(
        <div>
            <h1 className='show-title'>Details About: {pet.name}</h1>
            <dl className="row box">
                <dt className="col-sm-3">Pet Type</dt>
                <dd className="col-sm-9">{pet.petType}</dd>
                <hr/>
                <dt className="col-sm-3">Pet Description</dt>
                <dd className="col-sm-9">{pet.description}</dd>
                <hr/>
                <dt className="col-sm-3">Skill 1</dt>
                <dd className="col-sm-9">{pet.skill1}</dd>
                <hr/>
                <dt className="col-sm-3">Skill 2</dt>
                <dd className="col-sm-9">{pet.skill2}</dd>
                <hr/>
                <dt className="col-sm-3">Skill 3</dt>
                <dd className="col-sm-9">{pet.skill3}</dd>

            </dl>
            <div className="d-grid gap-2 col-6 mx-auto">
                <Link className='btn btn-primary' to={'/'}>Home</Link>
            </div>

        </div>
    );
};

export default ShowPet;