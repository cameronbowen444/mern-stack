import React, {useState, useEffect} from 'react';
import axios from 'axios';
import { useParams, Link, useNavigate } from 'react-router-dom';

const Update = (props) => {
    const {id} = useParams();
    const [name, setName] = useState("");
    const [petType, setPetType] = useState("");
    const [description, setDescription] = useState("");
    const [skill1, setSkill1] = useState("");
    const [skill2, setSkill2] = useState("");
    const [skill3, setSkill3] = useState("");
    const [errors, setErrors] = useState({});
    const navigate = useNavigate();

    useEffect(() => {
        axios.get('http://localhost:8000/api/pets/' + id)
        .then(res => {
            console.log(res.data);
            setName(res.data.name);
            setPetType(res.data.petType);
            setDescription(res.data.description);
            setSkill1(res.data.skill1);
            setSkill2(res.data.skill2);
            setSkill3(res.data.skill3);
        })
        .catch(err => {
            console.log(err.response);
        })
    }, [])

    const updateThisPet = (e) => {
        e.preventDefault();
        axios.put('http://localhost:8000/api/pets/edit/' + id, {
            name,
            petType,
            description,
            skill1,
            skill2,
            skill3
        })
        .then(res => {
            console.log(res);
            console.log(res.data);
            navigate("/");
        })
        .catch(err => {
            console.log(err.response.data.err.errors);
            setErrors(err.response.data.err.errors);
        })
    }
    return(
        <div>
            <div className='container'>
                <div className='row justify-content-between'>
                    <div className='col-4'>
                        <h5>Update Page</h5>
                    </div>
                    <div className='col-4 link'>
                        <Link className="btn btn-primary" to={'/'}>Home</Link>
                    </div>
                </div>
                <form onSubmit={updateThisPet} className="form">
                    <div className='row justify-content-between'>
                        <h2 className="form-title">Update {name}:</h2>
                        <div className='col-4'>
                            <div className='mb-3'>
                                <label className='form-label'>Pet Name</label>
                                <input className='form-control' type="text" value={name} onChange={(e) => setName(e.target.value)}/>
                                {
                                    errors.name ? <p className="error">{errors.name.message}</p> : null
                                }
                            </div>
                            <div className='mb-3'>
                                <label className='form-label'>Pet Type</label>
                                <input className='form-control' type="text" value={petType} onChange={(e) => setPetType(e.target.value)}/>
                                {
                                    errors.petType ? <p className="error">{errors.petType.message}</p> : null
                                }
                            </div>
                            <div className='mb-3'>
                                <label className='form-label'>Pet Description</label>
                                <input className='form-control' type="text" value={description} onChange={(e) => setDescription(e.target.value)}/>
                                {
                                    errors.description ? <p className="error">{errors.description.message}</p> : null
                                }
                            </div>
                        </div>
                        <div className='col-4'>
                            <p>Optional Skills:</p>
                            <div className='mb-3'>
                                <label className='form-label'>Pet Skill 1</label>
                                <input className='form-control' type="text" value={skill1} onChange={(e) => setSkill1(e.target.value)}/>
                            </div>
                            <div className='mb-3'>
                                <label className='form-label'>Pet Skill 2</label>
                                <input className='form-control' type="text" value={skill2} onChange={(e) => setSkill2(e.target.value)}/>
                            </div>
                            <div className='mb-3'>
                                <label className='form-label'>Pet Skill 3</label>
                                <input className='form-control' type="text" value={skill3} onChange={(e) => setSkill3(e.target.value)}/>
                            </div>
                        </div>
                        <div className="button">
                            <input type="submit" className="btn btn-primary btn4" />
                        </div>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default Update;