import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './App.css';
import Display from './Components/Display';
import PetForm from './Components/PetForm';
import ShowPet from './Components/ShowPet';
import Update from './Components/Update';

function App() {
  return (
    <div className="container">
      <h1 className='title'>Pet Shelter</h1>
      <hr/>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Display/>}/>
          <Route path="/new" element={<PetForm/>} />
          <Route path="/show/:id" element={<ShowPet/>} />
          <Route path="/edit/:id" element={<Update/>} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
