import React, {useState, useEffect} from 'react';
import {Link} from 'react-router-dom'
import axios from 'axios';

const AuthorList = (props) => {

    const [authors, setAuthors] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:8000/api/authors')
        .then(res => {
            console.log(res.data);
            setAuthors(res.data);
        })
        .catch(err => console.log(err));
    }, []);

    const deleteAuthor = (delId) => {
        axios.delete('http://localhost:8000/api/authors/' + delId)
        .then(res => {
            const filteredAuthor = authors.filter((author) => {
                return author._id !== delId;
            });
            setAuthors(filteredAuthor);
        })
        .catch(err => console.log(err))
    }

    return (
        <div>
            <Link to={'/new'}>Add Author</Link>
            {
                authors.map( (author, index) => {
                    return(
                        <div key={index}>
                            <p>{author.name}</p>
                            <Link to={"/edit/" + author._id}>Edit</Link>
                            <button onClick={() => deleteAuthor(author._id)}>Delete</button>
                        </div>
                    )
                })
            }
        </div>
    )
}

export default AuthorList;