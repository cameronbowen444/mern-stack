import React, { useState } from 'react';
import {Link, useNavigate} from 'react-router-dom';
import axios from 'axios';

const AuthorForm = (props) => {

    const [name, setName] = useState("");
    const [errors, setErrors] = useState({});
    const navigate = useNavigate();

    const onSubmitHandle = (e) => {
        e.preventDefault();
        setName('');
        axios.post('http://localhost:8000/api/authors', {
            name
        })
            .then(res => {
                console.log(res);
                console.log(res.data);
                navigate('/');
            })
            .catch(err => {
                console.log(err.response.data.err.errors);
                setErrors(err.response.data.err.errors);
            })
    }


    return (
        <div>
            <form onSubmit={onSubmitHandle}>
                <div>
                    <label>Name</label>
                    <input type="text" value={name} onChange={ (e) => setName(e.target.value) } />
                    {
                        errors.name ? <p>{errors.name.message}</p> : null
                    }
                </div>
                <div>
                    <input type="submit" value="Submit Author" />
                </div>
            </form>
        </div>
    )
}

export default AuthorForm;