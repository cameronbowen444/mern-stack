import React, {useState, useEffect} from 'react';
import axios from 'axios';
import {Link, useParams, useNavigate} from 'react-router-dom';

const Update = (props) => {
    const {id} = useParams();
    const [name, setName] = useState("");
    const [errors, setErrors] = useState({});
    const [noAuthor, setNoAuthor] = useState("");
    const navigate = useNavigate();

    useEffect(() => {
        axios.get('http://localhost:8000/api/authors/' + id)
            .then((res) => {
                console.log(res.data);
                setName(res.data.name);
            })
            .catch((err) => {
                console.log(err.response);
                setNoAuthor('Author id not found in database!');
            })
    }, []);

    const onSubmitUpdate = (e) => {
        e.preventDefault();
        axios.put('http://localhost:8000/api/authors/edit/' + id, {
            name
        })
            .then((res) => {
                console.log(res);
                console.log(res.data);
                navigate("/");
            })
            .catch((err) => {
                console.log(err.response.data.err.errors);
                setErrors(err.response.data.err.errors);
            })
    }

    return (
        <div>
            <Link to={"/"}>Home</Link>
            <form onSubmit={onSubmitUpdate}>
                {noAuthor ? ( 
                    <h2>{noAuthor} <Link to={"/new"}>Click here to add author</Link></h2> 
                ): null}
                <div>
                    <label>Name</label>
                    <input type="text" id="name" name="name" value={name} onChange={ (e) => setName(e.target.value) } />
                    {
                        errors.name ? 
                        <p>{errors.name.message}</p> : null
                    }
                </div>
                <div>
                    <input type="submit" value="Update Author" />
                </div>
            </form>
        </div>
    )
}

export default Update;