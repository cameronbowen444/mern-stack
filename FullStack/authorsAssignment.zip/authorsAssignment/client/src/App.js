import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './App.css';
import AuthorList from './Components/AuthorList';
import AuthorForm from './Components/AuthorForm';
import Update from './Components/Update';

function App() {
  return (
    <div className="App">
      <h1>Favorite Authors</h1>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<AuthorList/>} />
          <Route path="/new" element={<AuthorForm/>} />
          <Route path="/edit/:id" element={<Update/>} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
