import React, { useState } from 'react';
import axios from 'axios';

const ProductForm = ( props ) => {

    const [title, setTitle] = useState("");
    const [price, setPrice] = useState("");
    const [description, setDescription] = useState("");

    const onSubmitHandler = (e) => {
        e.preventDefault();

        axios.post('http://localhost:8000/api/products', {
            title,
            price,
            description
        })
            .then(res => {
                console.log(res);
                console.log(res.data);
            })
            .catch(err => console.log(err))
    }

    return(
        <div>
            <h1>Product Manager</h1>
            <form className="box-form" onSubmit={ onSubmitHandler }>
                <div className='box'>
                    <label>Title</label>
                    <input className='input' type="text" onChange={ (e) => setTitle(e.target.value) }/>
                </div>
                <div className='box'>
                    <label>Price</label>
                    <input className='input' type="number" onChange={ (e) => setPrice(e.target.value) }/>
                </div>
                <div className='box'>
                    <label>Description</label>
                    <input className='input' type="text" onChange={ (e) => setDescription(e.target.value) }/>
                </div>
                <input className='btn' type="submit" value="Add Product" />
            </form>
        </div>
    )
}

export default ProductForm;