import React from 'react';
import axios from 'axios';


const Delete = (props) => {

    const {playerId, succeCallBack} = props;

    const deletePlayer = (e) => {
        axios.delete('http://localhost:8000/api/players/' + playerId)
        .then(res => {
            succeCallBack();
        })
    }
    return(
        <div>
            <button onClick={deletePlayer}>Delete</button>
        </div>
    )
}

export default Delete;