import React, {useState, useEffect} from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import Delete from './Delete';

const Display = (props) => {

    const [players, setPlayers] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:8000/api/players')
        .then(res => {
            console.log(res);
            console.log(res.data);
            setPlayers(res.data);
        })
        .catch(err => {
            console.log(err);
        })
    }, [])

    const removePlayer = playerId => {
        setPlayers(players.filter(player => player._id !== playerId))
    }

    return(
        <div>
            <div class="row justify-content-between">
                <div class="col-4">
                    <h5>List Of All Players</h5>
                </div>
                <div class="col-4">
                    <Link className='btn btn-primary' to={'/new'}>Add Player</Link>
                </div>
            </div>
            <table className="table">
                <thead>
                    <tr>
                        <th scope="col">Player Name</th>
                        <th scope="col">Preferred Position</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        players.map((player, index) => {
                            return(
                                <tr key={index}>
                                    <td>{player.playerName}</td>
                                    <td>{player.playerPosition}</td>
                                    <td><Delete playerId={player._id} succeCallBack={ () => removePlayer(player._id) }/></td>
                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
            <Link to={'/status/game/'}>See Games</Link>
        </div>
    )
}

export default Display;