import React, {useState, useEffect} from 'react';
import axios from 'axios';


const Update = (props) => {
    return(
        <div>
            <h1>Hello</h1>
        </div>
    )
}

export default Update;