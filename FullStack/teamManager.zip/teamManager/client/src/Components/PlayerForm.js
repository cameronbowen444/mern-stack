import React, {useState, useEffect} from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';


const PlayerForm = (props) => {

    const [playerName, setPlayerName] = useState("");
    const [playerPosition, setPlayerPosition] = useState("");
    const [errors, setErrors] = useState({});
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.post('http://localhost:8000/api/players', {
            playerName,
            playerPosition
        })
        .then(res => {
            console.log(res);
            console.log(res.data);
            navigate('/')
        })
        .catch(err => {
            console.log(err.response.data.err.errors);
            setErrors(err.response.data.err.errors);
        })
    }
    return(
        <div className='container contain-form'>
            <form className='form' onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label className="form-label">Player Name</label>
                    <input type="text" className="form-control" value={playerName} onChange={(e) => setPlayerName(e.target.value)} />
                    {
                        errors.playerName ? <p className='errors'>{errors.playerName.message}</p> : null
                    }
                </div>
                <div className="mb-3">
                    <label className="form-label">Player Position</label>
                    <input type="text" className="form-control" onChange={(e) => setPlayerPosition(e.target.value)} />
                </div>
                <button type="submit" className="btn btn-primary">Submit</button>
            </form>
        </div>
    )
}

export default PlayerForm;