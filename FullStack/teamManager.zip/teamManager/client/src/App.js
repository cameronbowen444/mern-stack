import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import './App.css';
import Display from './Components/Display';
import PlayerForm from './Components/PlayerForm';
import Show from './Components/Show';
import Update from './Components/Update';

function App() {
  return (
    <div className="container">
      <h1>Team Manager</h1>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Display />} />
          <Route path="/new" element={<PlayerForm/>} />
          <Route path="/edit/:id" element={<Update/>} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
