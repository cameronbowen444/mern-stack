import React, {useState, useEffect} from 'react';
import './App.css';

function App() {

  const [text, setText] = useState("");
  const [todoList, setTodoList] = useState([]);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (text.length === 0) {
      return false;
    }

    const noteObject = {
      note : text,
      isChecked : false
    };

    setTodoList([...todoList, noteObject]);
  }

  const handleDelete = (delIdx) => {
    const filteredTodos = todoList.filter((_item, index) => {
      return index !== delIdx;
    });

    setTodoList(filteredTodos);
  }

  const handleCheck = (idx) => {
    const updatedTodos = todoList.map((item, index) => {
      if (idx === index) {
        const updatedTodos = { ...item, isChecked: !item.isChecked };
        return updatedTodos;
      }
      return item;
    });
    setTodoList(updatedTodos);
  }


  return (
    <div className="App">
      <h1>Todo List</h1>
      <form onSubmit={ (e) => handleSubmit(e) }>
        <input type="text" value={text} onChange={ (e) => setText(e.target.value) }/>
        <button>Add</button>
      </form>
      <div>
        <h1>Your Todos:</h1>
        {
          todoList.map( (item, index) => {
            const checkItem = ["p"];
            if (item.isChecked === true) {
              checkItem.push("checked-item");
            }
            return (
            <div className='note' key={index}>
              <input onChange={ (e) => handleCheck(index) } checked={item.isChecked} type="checkbox" />
              <p className={checkItem.join(" ")}>{ item.note }</p>
              <div>
                <button onClick={ (e) => {
                  handleDelete(index);
                }}>Delete</button>
              </div>
            </div>
            );
          })
        }
      </div>
    </div>
  );
}

export default App;
