import React, { useState } from 'react';

const BoxForm = (props) => {

    const [color, setColor] = useState("");

    const {boxColor, setBoxColor} = props;
    
    const handleSubmit = (e) => {
        e.preventDefault();
        setBoxColor( [...boxColor, color] );
    }

    return (
        <div>
            <h1>Box Generator</h1>
            <form onSubmit={handleSubmit}>
                <label htmlFor="">Color</label>
                <input class="input" type="text" onChange={ (e) => setColor(e.target.value) } value={ color } />
                <input class="btn" type="submit" value="Add" />
            </form>
        </div>
    );
};

export default BoxForm;