import React, { useState } from 'react';

const BoxDisplay = ( props ) => {

    const { boxes } = props;

    return(
        <div>
            <h1>Your Boxes Here...</h1>
            <pre className='box'>
                {
                    boxes.map( (color, index) => (
                        <div key={ index } style={{
                            height: '100px',
                            width: '100px',
                            backgroundColor: color,
                            margin: '20px',
                            padding: '10px',
                            }}>
                        </div>
                    ))
                }
            </pre>
        </div>
    );
}

export default BoxDisplay;