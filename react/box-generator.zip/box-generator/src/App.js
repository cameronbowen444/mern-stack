import './App.css';
import React, { useState } from 'react';
import BoxDisplay from './Components/BoxDisplay';
import BoxForm from './Components/BoxForm';

function App() {

  const [currentBox, setCurrentBox] = useState([]);

  const heresABox = ( newBox ) => {
    setCurrentBox( newBox );
  }

  return (
    <div className="App">
      <BoxForm boxColor={ currentBox } setBoxColor={ setCurrentBox }/>
      <BoxDisplay boxes={ currentBox } />
    </div>
  );
}

export default App;
