import React from "react";
import { useParams } from "react-router-dom";

const Params = ( props ) => {
    const {value, color, bg} = useParams();
    return (
        <div>
            {
                isNaN(value) ? 
                <h3 style={
                    color?
                    {color: color, backgroundColor: bg}
                    :null
                }>The Word is: { value }</h3> :
                <h3>The Number is: { value }</h3>
            }
        </div>
    );
}

export default Params;