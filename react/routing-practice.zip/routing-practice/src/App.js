import React from 'react';
import {BrowserRouter, Routes, Route} from 'react-router-dom';
import Home from './Components/Home';
import Params from './Components/Params';
import './App.css';


function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <Routes>
          <Route path="/home" element={<Home />} />
          <Route path="/:value" element={<Params />} />
          <Route path="/:value/:color/:bg" element={<Params />} />

        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
