import './App.css';
import UserForms from './components/UserForms';

function App() {
  return (
    <div className="App">
      <UserForms />
    </div>
  );
}

export default App;
