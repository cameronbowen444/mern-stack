import React, { useState } from 'react';

const UserForms = ( props ) => {
    const [firstName, setFirstName] = useState("");
    const [firstNameError, setFirstNameError] = useState("");
    const [lastName, setLastName] = useState("");
    const [lastNameError, setLastNameError] = useState("");
    const [email, setEmail] = useState("");
    const [emailError, setEmailError] = useState("");
    const [password, setPassword] = useState("");
    const [passwordError, setPasswordError] = useState("");
    const [confirm, setConfirm] = useState("");
    const [confirmError, setConfirmError] = useState("");


    const handleFirstName = (e) => {
        setFirstName(e.target.value);
        if (e.target.value.length < 1) {
            setFirstNameError("First Name is Required!");
        } else if(e.target.value.length < 2) {
            setFirstNameError("First Name must be at least 2 characters long!");
        } else {
            setFirstNameError("");
        }
    };
    const handleLastName = (e) => {
        setLastName(e.target.value);
        if (e.target.value.length < 1) {
            setLastNameError("Last Name is Required!");
        } else if(e.target.value.length < 2) {
            setLastNameError("Last Name must be at least 2 characters long!");
        } else {
            setLastNameError("");
        }
    };
    const handleEmail = (e) => {
        setEmail(e.target.value);
        if (e.target.value.length < 1) {
            setEmailError("Email is Required!");
        } else if(e.target.value.length < 2) {
            setEmailError("Email must be at least 2 characters long!");
        } else {
            setEmailError("");
        }
    };
    const handlePassword = (e) => {
        setPassword(e.target.value);
        if (e.target.value.length < 1) {
            setPasswordError("Password is Required!");
        } else if(e.target.value.length < 8) {
            setPasswordError("Password must be at least 8 characters long!");
        } else {
            setPasswordError("");
        }
    };
    const handleConfirm = (e) => {
        setConfirm(e.target.value);
        if(e.target.value.length < 8) {
            setConfirmError("Password Confirmation must be at least 8 characters long!");
        } else if (e.target.value !== password) {
            setConfirmError("Passwords Must Match")
        } else {
            setConfirmError("");
        }
    };
    const createUser = (e) => {
        const newUser = {firstName, lastName, email, password};
        e.preventDefault();
        console.log("Welcome", newUser);
        setFirstName("");
        setLastName("");
        setEmail("");
        setPassword("");
    };

    const errors = () => {
        if (firstNameError) {
            return <input type="submit" value="Create User" disabled />;
        } else if (lastNameError) {
            return <input type="submit" value="Create User" disabled />;
        } else if (emailError) {
            return <input type="submit" value="Create User" disabled />;
        } else if (passwordError) {
            return <input type="submit" value="Create User" disabled />;
        } else if (confirmError) {
            return <input type="submit" value="Create User" disabled />;
        }else {
            return <input type="submit" value="Create User" />;
        }
    };

    return (
        <div>
            <form onSubmit={ createUser }>
                <div>
                    <label>First Name: </label>
                    <input class="valid" type="text" value={firstName} onChange={handleFirstName} />
                    {
                        firstNameError ?
                        <p>{ firstNameError }</p> :
                        null
                    }
                </div>
                <div>
                    <label>Last Name: </label>
                    <input class="valid" type="text" value={lastName} onChange={handleLastName} />
                    {
                        lastNameError ?
                        <p>{ lastNameError }</p> :
                        null
                    }
                </div>
                <div>
                    <label>Email: </label>
                    <input class="valid" type="text" value={email} onChange={handleEmail} />
                    {
                        emailError ?
                        <p>{ emailError }</p> :
                        null
                    }
                </div>
                <div>
                    <label>Password: </label>
                    <input class="valid" type="text" value={password} onChange={handlePassword} />
                    {
                        passwordError ?
                        <p>{ passwordError }</p> :
                        null
                    }
                </div>
                <div>
                    <label>Password Confirm: </label>
                    <input class="valid" type="text" value={confirm} onChange={handleConfirm} />
                    {
                        confirmError ?
                        <p>{ confirmError }</p> :
                        null
                    }
                </div>
                <h5>{ errors() }</h5>
            </form>
        </div>
    );
}

export default UserForms;