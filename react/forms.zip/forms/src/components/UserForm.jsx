import React, {useState} from 'react';

const UserForm = ( props ) => {

    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirm, setConfirm] = useState("");

    const createUser = (e) => {

        e.preventDefault();

        const newUser = { firstName, lastName, email, password, confirm };
        console.log("Welcome", newUser);
        setFirstName("");
        setLastName("");
        setEmail("");
        setPassword("");
        setConfirm("");
    };

    return(
        <div>
            <form class="form" onSubmit={ createUser }>
                <div class="md">
                    <label>First Name: </label>
                    <input type="text" value={firstName} onChange={ (e) => setFirstName(e.target.value) } />
                </div>
                <div class="md">
                    <label>Last Name: </label>
                    <input type="text" value={lastName} onChange={ (e) => setLastName(e.target.value) } />
                </div>
                <div class="md">
                    <label>Email: </label>
                    <input type="text" value={email} onChange={ (e) => setEmail(e.target.value) } />
                </div>
                <div class="md">
                    <label>Password: </label>
                    <input type="password" value={password} onChange={ (e) => setPassword(e.target.value) } />
                </div>
                <div class="md">
                    <label>Confirm Password: </label>
                    <input type="password" value={confirm} onChange={ (e) => setConfirm(e.target.value) } />
                </div>
                <input type="submit" value="Create User" />
            </form>
            <h1>Your Form Data:</h1>
            <div class="cent">
                <div class="center">
                    <label>First Name: </label>
                    <p>{firstName}</p>
                </div>
                <div class="center">
                    <label>Last Name: </label>
                    <p>{lastName}</p>
                </div>
                <div class="center">
                    <label>Email: </label>
                    <p>{email}</p>
                </div>
                <div class="center">
                    <label>Password: </label>
                    <p>{password}</p>
                </div>
                <div class="center">
                    <label>Confirm Password: </label>
                    <p>{confirm}</p>
                </div>
            </div>
            

        </div>
    );
}

export default UserForm;